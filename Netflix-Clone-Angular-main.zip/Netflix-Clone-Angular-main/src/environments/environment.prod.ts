export const environment = {
  firebase: {
    projectId: 'login-firebase-auth-3225b',
    appId: '1:286999975693:web:c259402950af16ba334244',
    storageBucket: 'login-firebase-auth-3225b.appspot.com',
    apiKey: 'AIzaSyBNw9cimeg0fKNN7fe9aWX166dlumfXAGc',
    authDomain: 'login-firebase-auth-3225b.firebaseapp.com',
    messagingSenderId: '286999975693',
  },
  production: true
};
