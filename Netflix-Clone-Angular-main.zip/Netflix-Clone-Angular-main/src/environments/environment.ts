// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'login-firebase-auth-3225b',
    appId: '1:286999975693:web:c259402950af16ba334244',
    storageBucket: 'login-firebase-auth-3225b.appspot.com',
    apiKey: 'AIzaSyBNw9cimeg0fKNN7fe9aWX166dlumfXAGc',
    authDomain: 'login-firebase-auth-3225b.firebaseapp.com',
    messagingSenderId: '286999975693',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
